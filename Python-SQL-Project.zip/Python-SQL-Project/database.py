
import sqlite3
from flask import g
from pathlib import Path
DB_PATH = Path(__file__).parent / "music_analytics.db"
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db
def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()
def create_tables_and_seed():
    conn = sqlite3.connect(DB_PATH); cur = conn.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS songs (song_id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, artist TEXT, album TEXT, genre TEXT, url TEXT NOT NULL, thumbnail TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    cur.execute('''CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, email TEXT)''')
    cur.execute('''CREATE TABLE IF NOT EXISTS streams (stream_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, song_id INTEGER, timestamp TEXT DEFAULT CURRENT_TIMESTAMP)''')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_streams_song ON streams(song_id)'); cur.execute('CREATE INDEX IF NOT EXISTS idx_streams_user ON streams(user_id)')
    conn.commit()
    cur.execute('SELECT COUNT(*) FROM songs'); count = cur.fetchone()[0]
    if count == 0:
        # real song titles mapped to sample mp3 URLs for demo
        samples = [
            ('Blinding Lights', 'The Weeknd', 'After Hours', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'),
            ('Levitating', 'Dua Lipa', 'Future Nostalgia', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'),
            ('Save Your Tears', 'The Weeknd', 'After Hours', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3'),
            ('Peaches', 'Justin Bieber', 'Justice', 'R&B', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3'),
            ('Drivers License', 'Olivia Rodrigo', 'SOUR', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3'),
            ('Stay', 'The Kid LAROI', 'F*CK LOVE', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'),
            ('Bad Habits', 'Ed Sheeran', '=', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'),
            ('Montero', 'Lil Nas X', 'Montero', 'Rap', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3'),
            ('Watermelon Sugar', 'Harry Styles', 'Fine Line', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3'),
            ('Circles', 'Post Malone', "Hollywood's Bleeding", 'Hip-Hop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3'),
            ('Believer', 'Imagine Dragons', 'Evolve', 'Rock', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'),
            ('Thunder', 'Imagine Dragons', 'Evolve', 'Rock', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'),
            ('Counting Stars', 'OneRepublic', 'Native', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3'),
            ('Someone You Loved', 'Lewis Capaldi', 'Divinely Uninspired', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3'),
            ('Sunflower', 'Post Malone', 'Hollywood', 'Hip-Hop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3'),
            ('Closer', 'The Chainsmokers', 'Collage', 'EDM', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'),
            ('Happier', 'Marshmello', 'Joytime', 'EDM', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'),
            ('Perfect', 'Ed Sheeran', 'Divide', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3'),
            ('Rockstar', 'Post Malone', 'Beerbongs', 'Hip-Hop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3'),
            ('Memories', 'Maroon 5', 'Jordi', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3')
        ]
        for i, (title, artist, album, genre, url) in enumerate(samples, start=1):
            thumbnail = f'static/images/thumb_{((i-1)%5)+1}.svg'
            cur.execute('INSERT INTO songs (title, artist, album, genre, url, thumbnail) VALUES (?, ?, ?, ?, ?, ?)', (title, artist, album, genre, url, thumbnail))
        users = [('alice','alice@example.com'), ('bob','bob@example.com')]; cur.executemany('INSERT INTO users (username, email) VALUES (?, ?)', users)
        conn.commit(); cur.execute('SELECT song_id FROM songs'); ids = [r[0] for r in cur.fetchall()]
        import random
        for _ in range(300): sid = random.choice(ids); cur.execute('INSERT INTO streams (user_id, song_id, timestamp) VALUES (?, ?, datetime("now"))', (None, sid))
        conn.commit()
    conn.close()
def init_app(app):
    app.teardown_appcontext(close_db); create_tables_and_seed()
if __name__ == '__main__': create_tables_and_seed(); print('DB ready')
