
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from database import init_app, get_db
from datetime import datetime
app = Flask(__name__)
app.secret_key = 'wavebeat_v3_secret'
init_app(app)
def rowlist_to_dict(rows): return [dict(r) for r in rows]
@app.route('/')
def index():
    db = get_db(); cur = db.cursor()
    cur.execute("SELECT COUNT(*) FROM songs"); total_songs = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM users"); total_users = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM streams"); total_streams = cur.fetchone()[0]
    cur.execute('''SELECT s.song_id, s.title, s.artist, s.genre, s.thumbnail, COUNT(st.stream_id) AS plays
                   FROM songs s LEFT JOIN streams st ON s.song_id = st.song_id
                   GROUP BY s.song_id ORDER BY plays DESC LIMIT 20''')
    top_songs = rowlist_to_dict(cur.fetchall())
    cur.execute("SELECT song_id, title, artist, genre, thumbnail FROM songs ORDER BY song_id DESC LIMIT 20")
    recent_songs = rowlist_to_dict(cur.fetchall())
    return render_template('index.html', total_songs=total_songs, total_users=total_users, total_streams=total_streams, top_songs=top_songs, recent_songs=recent_songs)
@app.route('/songs')
def songs():
    db = get_db(); cur = db.cursor()
    cur.execute("SELECT * FROM songs ORDER BY song_id DESC")
    songs = rowlist_to_dict(cur.fetchall())
    cur.execute("SELECT song_id, COUNT(*) as plays FROM streams GROUP BY song_id")
    plays = {r['song_id']: r['plays'] for r in cur.fetchall()}
    return render_template('songs.html', songs=songs, plays=plays)
@app.route('/songs/add', methods=['POST'])
def add_song():
    title = request.form.get('title','').strip(); artist = request.form.get('artist','').strip()
    album = request.form.get('album','').strip(); genre = request.form.get('genre','').strip()
    url = request.form.get('url','').strip(); thumbnail = request.form.get('thumbnail','').strip() or None
    if not title or not url:
        flash('Title and MP3 URL are required','danger'); return redirect(request.referrer or url_for('index'))
    db = get_db(); cur = db.cursor()
    cur.execute("INSERT INTO songs (title, artist, album, genre, url, thumbnail, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (title, artist, album, genre, url, thumbnail, datetime.now().isoformat()))
    db.commit(); flash('Song added','success'); return redirect(url_for('songs'))
@app.route('/songs/<int:song_id>/delete', methods=['POST'])
def delete_song(song_id):
    db = get_db(); cur = db.cursor(); cur.execute("DELETE FROM songs WHERE song_id=?", (song_id,)); cur.execute("DELETE FROM streams WHERE song_id=?", (song_id,)); db.commit(); flash('Song deleted','info'); return redirect(request.referrer or url_for('songs'))
@app.route('/songs/<int:song_id>/edit', methods=['POST'])
def edit_song(song_id):
    title = request.form.get('title','').strip(); artist = request.form.get('artist','').strip(); album = request.form.get('album','').strip()
    genre = request.form.get('genre','').strip(); url = request.form.get('url','').strip(); thumbnail = request.form.get('thumbnail','').strip() or None
    if not title or not url:
        flash('Title and URL required', 'danger'); return redirect(request.referrer or url_for('songs'))
    db = get_db(); cur = db.cursor(); cur.execute("UPDATE songs SET title=?, artist=?, album=?, genre=?, url=?, thumbnail=? WHERE song_id=?", (title, artist, album, genre, url, thumbnail, song_id)); db.commit(); flash('Song updated','success'); return redirect(request.referrer or url_for('songs'))
@app.route('/player')
def player():
    db = get_db(); cur = db.cursor(); cur.execute("SELECT * FROM songs ORDER BY song_id DESC"); songs = rowlist_to_dict(cur.fetchall()); return render_template('player.html', songs=songs)
@app.route('/streams/record', methods=['POST'])
def record_stream():
    data = request.get_json() or {}; song_id = data.get('song_id')
    if not song_id: return jsonify({'ok': False}), 400
    db = get_db(); cur = db.cursor(); cur.execute("INSERT INTO streams (user_id, song_id, timestamp) VALUES (?, ?, ?)", (None, song_id, datetime.now().isoformat())); db.commit(); return jsonify({'ok': True})
@app.route('/analytics')
def analytics():
    db = get_db(); cur = db.cursor(); cur.execute("SELECT s.title, COUNT(st.stream_id) as plays FROM songs s LEFT JOIN streams st ON s.song_id=st.song_id GROUP BY s.song_id ORDER BY plays DESC LIMIT 20"); top = rowlist_to_dict(cur.fetchall()); labels = [r['title'] for r in top]; values = [r['plays'] for r in top]; return render_template('analytics.html', labels=labels, values=values, top=top)
@app.route('/users')
def users():
    db = get_db(); cur = db.cursor(); cur.execute("SELECT u.*, (SELECT COUNT(*) FROM streams st WHERE st.user_id = u.user_id) as total_streams FROM users u ORDER BY user_id DESC"); users = rowlist_to_dict(cur.fetchall()); return render_template('users.html', users=users)
@app.route('/users/add', methods=['POST'])
def add_user():
    username = request.form.get('username','').strip(); email = request.form.get('email','').strip() or None
    if not username: flash('Username required','danger'); return redirect(request.referrer or url_for('users'))
    db = get_db(); cur = db.cursor(); cur.execute("INSERT INTO users (username, email) VALUES (?, ?)", (username, email)); db.commit(); flash('User added','success'); return redirect(request.referrer or url_for('users'))
@app.route('/users/<int:user_id>/edit', methods=['POST'])
def edit_user(user_id):
    username = request.form.get('username','').strip(); email = request.form.get('email','').strip() or None
    if not username:
        flash('Username required','danger'); return redirect(request.referrer or url_for('users'))
    db = get_db(); cur = db.cursor(); cur.execute("UPDATE users SET username = ?, email = ? WHERE user_id = ?", (username, email, user_id)); db.commit(); flash('User updated','success'); return redirect(request.referrer or url_for('users'))
if __name__ == '__main__':
    app.run(debug=True)
